# Wil-Cliff Package

A simple Python package to perform Wilcoxon test and Cliff's Delta analysis.

## Installation

```bash
pip install wil_cliff

